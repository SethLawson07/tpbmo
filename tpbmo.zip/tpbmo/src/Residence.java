import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("7421fd94-ee11-4b9c-bda2-ca26b2d2f308")
public class Residence {
    @objid ("a0525f4c-31ee-4b58-a4f8-d11ccfdc1073")
    public String nom;

    @objid ("c8a5792c-0b99-4ad5-b6a8-e528094197e5")
    public String adresse;

    @objid ("6ba8f8c2-0be2-4706-b203-991074ebd05c")
    public String description;

    @objid ("ea0c2df7-1418-4e83-8e15-8bf09b7de34c")
    public Date createdAt;

    @objid ("c3fbcaf1-7429-442d-8936-41acb5213109")
    public Date updatedAt;

    @objid ("91b018d9-9722-458c-9c86-bc1ce8d84397")
    public List<Materiel>  = new ArrayList<Materiel> ();

    @objid ("a1285394-702c-465e-8d46-07c8496b064a")
    public List<Prestation>  = new ArrayList<Prestation> ();

    @objid ("fc59a837-3933-43b5-b5de-3c4817fdb607")
    public List<ElementResidence>  = new ArrayList<ElementResidence> ();

    @objid ("501b8131-53cf-4e99-9ae3-e43f6774ebe8")
    public void ajouterRésidence(résidence: Résidence)() {
    }

    @objid ("7dad0dca-eda7-472c-84a0-50a38e790329")
    public void modifierRésidence(résidence: Résidence)() {
    }

}
