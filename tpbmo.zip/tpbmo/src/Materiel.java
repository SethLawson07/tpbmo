import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("8b8b77ec-17dd-4698-9305-43859b1b8afd")
public class Materiel {
    @objid ("e147e05f-47ac-4d79-84bd-0f45ce49b170")
    public String nom;

    @objid ("69ec152d-79f5-4556-8065-e15609692c66")
    public String description;

    @objid ("31683dc5-8c23-417c-bdd9-6faf456a2573")
    public boolean disponible;

    @objid ("c6922adb-3c94-46aa-888a-d923662d93b2")
    public double tarif;

    @objid ("3c8d2458-b451-4a9f-b3b5-2aacb619d928")
    public void verifierDisponibilité(dateDébut: Date, dateFin: Date): boolean() {
    }

}
