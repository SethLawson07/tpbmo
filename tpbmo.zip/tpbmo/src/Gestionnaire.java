import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d8bc6c36-3393-451f-a585-18fb904488d2")
public class Gestionnaire {
    @objid ("2e09672c-1bcd-4dfd-92e8-0932ed5b4b49")
    public String nom;

    @objid ("68fad676-a7c4-4b52-b49a-0f312f56a91c")
    public String prenom;

    @objid ("3e8e275d-a03c-438b-a53f-829635936d7b")
    public String email;

    @objid ("e4281c27-1425-43e7-a317-0fd423e27003")
    public String tel;

    @objid ("5b95b709-8b23-420a-8fcd-fdb0ee0be22c")
    public String password;

    @objid ("ce49b58c-f619-468d-95ee-a84b470b5771")
    public Date createdAt;

    @objid ("72b85827-5041-4377-9fde-6513bdd475e8")
    public Date updatedAt;

    @objid ("a05e93d4-c775-4dbf-9305-c6b1691b5a4d")
    public void gererDisponibilites(residence : Residence)() {
    }

    @objid ("8e258eb5-cbce-400a-b360-14c66344baa0")
    public void gererTarifs(residence : Residence)() {
    }

    @objid ("46ed3457-0eca-4a03-bca8-ecd02dd6bb65")
    public void validerAvis(avis : Avis)() {
    }

}
