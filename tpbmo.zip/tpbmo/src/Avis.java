import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("04640b99-0079-4b6b-a773-1173d67301ea")
public class Avis {
    @objid ("1d8e61e9-b9f5-46a3-8fee-196351e8311d")
    public String note;

    @objid ("f4eccdc2-f2fb-4213-9b58-d28d51b76047")
    public String commentaire;

    @objid ("5316ce2c-acc3-4bac-acdd-08529dcaa55b")
    public Date createdAt;

    @objid ("f71e4032-ba03-4ae4-b525-0c39f0550af8")
    public Date updatedAt;

    @objid ("826b03d6-f4e6-4ae7-b571-0b96782016b9")
    public String status;

    @objid ("332fb240-75b6-4b52-98f1-c99d2256de74")
    public void estValide(): boolean() {
    }

}
