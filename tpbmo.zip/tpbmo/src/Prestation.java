import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("a1fcf7fc-958c-4d3f-8058-a60d2c09000d")
public class Prestation {
    @objid ("13d570ce-0341-42bb-9763-029e15351f33")
    public String nom;

    @objid ("8aa4213d-389c-4df1-af6c-ab0539d4f3a6")
    public String description;

    @objid ("e1ec75ab-f76b-42e7-9471-a356910f715f")
    public boolean disponible;

    @objid ("525b622a-7473-48a2-9e60-7f294d088389")
    public double tarif;

    @objid ("a6e98f77-bd90-445b-a7ab-33a88369844d")
    public void verifierDisponibilité(dateDébut: Date, dateFin: Date): boolean() {
    }

}
