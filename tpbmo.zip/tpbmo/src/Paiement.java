import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("074aebdd-389a-4eb7-ac9e-faf0281add91")
public class Paiement {
    @objid ("5b024803-ff86-4868-bf3d-78c26172d913")
    public Date createdAt;

    @objid ("99c40c87-ff07-40d2-9648-77dfe1870e8c")
    public Date updatedAt;

    @objid ("b5dd97fa-7f79-4cde-9318-1ad25cb8e839")
    public double montant;

    @objid ("e74be772-2424-4456-af19-3be6ba7a71ae")
    public boolean status;

    @objid ("da4b6bcc-8d9b-4cef-95dc-4516700322ce")
    public String methodePaiement;

    @objid ("277263e3-f24c-4a9d-9d19-656cd83321ba")
    public void effectuerPaiement()() {
    }

    @objid ("00b64ee6-1588-45ce-a69e-e21770bff8ed")
    public void rembourserPaiement()() {
    }

    @objid ("87673ee9-53bc-4dc0-97d0-6eb8992a3571")
    public void verifierStatutPaiement()() {
    }

}
