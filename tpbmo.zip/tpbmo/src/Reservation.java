import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c7cf1497-0670-4e23-88be-d17424e9ff8f")
public class Reservation {
    @objid ("f3c95672-2af9-44da-a5a7-6208befc3184")
    public Date startAt;

    @objid ("e21e3570-d6a6-41db-a0ed-97c8f4d3b1e8")
    public Date endAt;

    @objid ("ba2c4830-e5c0-4e4c-8eff-2f4c5964af8d")
    public int nbPersonne;

    @objid ("2116c27a-92c7-4d15-9779-d6fdd1e2e2ee")
    public double prixTotal;

    @objid ("44eb5762-e6a7-47ff-b34f-817465fe67b0")
    public String status;

    @objid ("28b1d9bf-eac2-4017-99d0-ed6f1cab821e")
    public Residence ;

    @objid ("9e06ba2c-2052-4090-84e6-f14d71b6bb9c")
    public void confirmer()() {
    }

    @objid ("92056332-014e-4208-b37a-07fe13bdd193")
    public void annuler()() {
    }

    @objid ("5a4bd5b5-ea1e-4d53-be6f-8ff84d39470f")
    public void calculerMontantTotal(): double() {
    }

}
