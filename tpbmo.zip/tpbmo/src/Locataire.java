import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("c636c8b7-a741-4760-83e0-e2d64293c91a")
public class Locataire {
    @objid ("0cfb2e1a-5116-4d84-90fb-1e0ed94033cb")
    public String nom;

    @objid ("90495c31-0111-466d-bea8-68db71692340")
    public String prenom;

    @objid ("807b8fba-329e-4ffe-83f7-381b97e0ca93")
    public String email;

    @objid ("efe461d8-1a27-40b3-81ae-e6e0751f7898")
    public String tel;

    @objid ("a92e28e9-5edc-4e08-ac61-13ad970fc530")
    public String password;

    @objid ("1c6e1178-9363-409a-86ef-03c3ee830613")
    public Date createdAt;

    @objid ("863dbbc6-0393-40a7-9653-8d085c5a05cb")
    public Date updatedAt;

    @objid ("4ec421c8-4b5b-4994-9637-48a2bccfc4c4")
    public void réserver(résidence: Résidence, dateDébut: Date, dateFin: Date): Réservation() {
    }

    @objid ("0d5727f5-020d-4feb-b9a2-4e549fbad645")
    public void payer(réservation: Réservation, montant: double): boolean() {
    }

    @objid ("e7f50bf1-fd72-419d-a231-eee953aac3e0")
    public void laisserAvis(réservation: Réservation, note: int, commentaire: String): Avis() {
    }

}
