import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9717e981-2157-41a0-80ba-114d849bfa70")
public class ElementResidence {
    @objid ("d520efb1-3e5f-4775-9489-f91d54fe0056")
    public String nom;

    @objid ("e92b6881-87f5-4564-a29c-693a5cca29e5")
    public double tarif;

    @objid ("7ad4a254-4c8b-466f-84be-9e4762589925")
    public boolean disponible;

    @objid ("f7618e65-43fc-40cb-9594-6f72c80bf0b7")
    public String description;

    @objid ("190ea093-26a8-4c61-9333-f07c565593a5")
    public void getDisponibilites(dateDebut , dateFin)() {
    }

    @objid ("f80769b3-206f-413c-89a5-ce47faacfa8e")
    public void getTarif(dateDebut , dateFin)() {
    }

}
